import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await req.json();
    const reward = await prisma.reward.update({
      where: { id: params.id },
      data: {
        name: body.name,
        description: body.description,
        pointsCost: body.pointsCost ? parseInt(body.pointsCost) : undefined,
        category: body.category,
        stock: body.stock !== undefined ? parseInt(body.stock) : undefined,
        isActive: body.isActive,
        validUntil: body.validUntil ? new Date(body.validUntil) : null,
      },
    });
    return NextResponse.json(reward);
  } catch (error) {
    console.error('Reward PUT error:', error);
    return NextResponse.json({ error: 'Error al actualizar recompensa' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    await prisma.reward.delete({ where: { id: params.id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Reward DELETE error:', error);
    return NextResponse.json({ error: 'Error al eliminar recompensa' }, { status: 500 });
  }
}
