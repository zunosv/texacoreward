import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const status = searchParams.get('status');
  const page = parseInt(searchParams.get('page') || '1');
  const limit = parseInt(searchParams.get('limit') || '50');

  try {
    const where: any = {};
    if (status) where.status = status;

    const [redemptions, total] = await Promise.all([
      prisma.redemption.findMany({
        where,
        orderBy: { redeemedAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
        include: {
          customer: { select: { firstName: true, lastName: true, phone: true } },
          reward: { select: { name: true, category: true, pointsCost: true } },
        },
      }),
      prisma.redemption.count({ where }),
    ]);

    return NextResponse.json({ redemptions, total, pages: Math.ceil(total / limit) });
  } catch (error) {
    console.error('Redemptions GET error:', error);
    return NextResponse.json({ error: 'Error al obtener canjes' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await req.json();
    const { customerId, rewardId } = body;

    if (!customerId || !rewardId) return NextResponse.json({ error: 'Cliente y recompensa son requeridos' }, { status: 400 });

    const [customer, reward] = await Promise.all([
      prisma.customer.findUnique({ where: { id: customerId } }),
      prisma.reward.findUnique({ where: { id: rewardId } }),
    ]);

    if (!customer) return NextResponse.json({ error: 'Cliente no encontrado' }, { status: 404 });
    if (!reward) return NextResponse.json({ error: 'Recompensa no encontrada' }, { status: 404 });
    if (!reward.isActive) return NextResponse.json({ error: 'Recompensa no disponible' }, { status: 400 });
    if (customer.totalPoints < reward.pointsCost) return NextResponse.json({ error: `Puntos insuficientes. Necesita ${reward.pointsCost}, tiene ${customer.totalPoints}` }, { status: 400 });
    if (reward.stock !== -1 && reward.stock <= 0) return NextResponse.json({ error: 'Recompensa sin stock' }, { status: 400 });

    const redemption = await prisma.redemption.create({
      data: { customerId, rewardId, pointsSpent: reward.pointsCost },
    });

    // Deduct points and update stock
    await prisma.customer.update({
      where: { id: customerId },
      data: { totalPoints: { decrement: reward.pointsCost } },
    });

    if (reward.stock !== -1) {
      await prisma.reward.update({ where: { id: rewardId }, data: { stock: { decrement: 1 } } });
    }

    return NextResponse.json(redemption, { status: 201 });
  } catch (error) {
    console.error('Redemption POST error:', error);
    return NextResponse.json({ error: 'Error al procesar canje' }, { status: 500 });
  }
}
