import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const search = searchParams.get('search') || '';
  const tier = searchParams.get('tier') || '';
  const page = parseInt(searchParams.get('page') || '1');
  const limit = parseInt(searchParams.get('limit') || '50');

  try {
    const where: any = {};
    if (search) {
      where.OR = [
        { firstName: { contains: search, mode: 'insensitive' } },
        { lastName: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search } },
        { email: { contains: search, mode: 'insensitive' } },
      ];
    }
    if (tier) where.tier = tier;

    const [customers, total] = await Promise.all([
      prisma.customer.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
        include: { _count: { select: { transactions: true, redemptions: true } } },
      }),
      prisma.customer.count({ where }),
    ]);

    return NextResponse.json({ customers, total, pages: Math.ceil(total / limit) });
  } catch (error) {
    console.error('Customers GET error:', error);
    return NextResponse.json({ error: 'Error al obtener clientes' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await req.json();
    const { firstName, lastName, email, phone, dpi } = body;

    if (!firstName || !lastName || !phone) {
      return NextResponse.json({ error: 'Nombre, apellido y teléfono son requeridos' }, { status: 400 });
    }

    const existing = await prisma.customer.findUnique({ where: { phone } });
    if (existing) return NextResponse.json({ error: 'Ya existe un cliente con ese teléfono' }, { status: 400 });

    if (email) {
      const existingEmail = await prisma.customer.findUnique({ where: { email } });
      if (existingEmail) return NextResponse.json({ error: 'Ya existe un cliente con ese email' }, { status: 400 });
    }

    const customer = await prisma.customer.create({
      data: { firstName, lastName, email: email || null, phone, dpi: dpi || null },
    });

    return NextResponse.json(customer, { status: 201 });
  } catch (error) {
    console.error('Customers POST error:', error);
    return NextResponse.json({ error: 'Error al crear cliente' }, { status: 500 });
  }
}
