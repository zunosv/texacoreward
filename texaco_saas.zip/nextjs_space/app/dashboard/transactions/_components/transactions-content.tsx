'use client'

import { useEffect, useState, useCallback } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { toast } from 'sonner'
import { ArrowLeftRight, Plus, Star, Search } from 'lucide-react'

const FUEL_TYPES = ['REGULAR', 'PREMIUM', 'DIESEL']
const TX_TYPES = ['FUEL', 'STORE', 'BONUS']

function formatNumber(n: number) { return new Intl.NumberFormat('es-GT').format(n) }
function formatCurrency(n: number) { return `Q ${new Intl.NumberFormat('es-GT', { minimumFractionDigits: 2 }).format(n)}` }

export function TransactionsContent() {
  const [transactions, setTransactions] = useState<any[]>([])
  const [stations, setStations] = useState<any[]>([])
  const [customers, setCustomers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [stationFilter, setStationFilter] = useState('')
  const [days, setDays] = useState('30')
  const [customerSearch, setCustomerSearch] = useState('')
  const [form, setForm] = useState({ customerId: '', stationId: '', type: 'FUEL', fuelType: 'REGULAR', gallons: '', amount: '', description: '' })

  const fetchTransactions = useCallback(() => {
    const params = new URLSearchParams({ days })
    if (stationFilter) params.set('stationId', stationFilter)
    fetch(`/api/transactions?${params}`)
      .then(r => r.json())
      .then(d => setTransactions(d.transactions || []))
      .catch(() => toast.error('Error'))
      .finally(() => setLoading(false))
  }, [stationFilter, days])

  useEffect(() => { fetchTransactions() }, [fetchTransactions])
  useEffect(() => { fetch('/api/stations').then(r => r.json()).then(setStations) }, [])

  useEffect(() => {
    if (customerSearch.length >= 2) {
      fetch(`/api/customers?search=${customerSearch}&limit=10`)
        .then(r => r.json())
        .then(d => setCustomers(d.customers || []))
    } else {
      setCustomers([])
    }
  }, [customerSearch])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const payload = {
        ...form,
        gallons: form.gallons ? parseFloat(form.gallons) : null,
        amount: parseFloat(form.amount),
      }
      const res = await fetch('/api/transactions', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
      const data = await res.json()
      if (!res.ok) { toast.error(data.error); return }
      let msg = `Transacción registrada: +${formatNumber(data.pointsEarned)} puntos`
      if (data.tierUpgrade) msg += ` ¡Subió a nivel ${data.tierUpgrade}!`
      toast.success(msg)
      setDialogOpen(false)
      setForm({ customerId: '', stationId: '', type: 'FUEL', fuelType: 'REGULAR', gallons: '', amount: '', description: '' })
      setCustomerSearch('')
      fetchTransactions()
    } catch { toast.error('Error') }
  }

  const totals = transactions.reduce((acc, t) => ({ amount: acc.amount + t.amount, points: acc.points + t.pointsEarned, count: acc.count + 1 }), { amount: 0, points: 0, count: 0 })

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold tracking-tight flex items-center gap-2">
            <ArrowLeftRight className="w-6 h-6 text-primary" /> Transacciones
          </h2>
          <p className="text-sm text-muted-foreground mt-1">Registra compras y acumula puntos para clientes</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="w-4 h-4 mr-2" /> Nueva Transacción</Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>Registrar Transacción</DialogTitle></DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Customer search */}
              <div className="space-y-2">
                <Label>Cliente *</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input placeholder="Buscar por nombre o teléfono..." value={customerSearch} onChange={(e: any) => { setCustomerSearch(e.target.value); setForm({ ...form, customerId: '' }) }} className="pl-9" />
                </div>
                {customers.length > 0 && !form.customerId && (
                  <div className="border rounded-lg max-h-32 overflow-y-auto">
                    {customers.map(c => (
                      <button key={c.id} type="button" onClick={() => { setForm({ ...form, customerId: c.id }); setCustomerSearch(`${c.firstName} ${c.lastName} - ${c.phone}`) }} className="w-full text-left px-3 py-2 text-sm hover:bg-muted transition-colors">
                        {c.firstName} {c.lastName} <span className="text-muted-foreground">({c.phone})</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <div className="space-y-2">
                <Label>Estación *</Label>
                <Select value={form.stationId} onValueChange={v => setForm({ ...form, stationId: v })}>
                  <SelectTrigger><SelectValue placeholder="Seleccionar estación" /></SelectTrigger>
                  <SelectContent>{stations.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Tipo *</Label>
                  <Select value={form.type} onValueChange={v => setForm({ ...form, type: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="FUEL">Combustible</SelectItem>
                      <SelectItem value="STORE">Tienda</SelectItem>
                      <SelectItem value="BONUS">Bono</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {form.type === 'FUEL' && (
                  <div className="space-y-2">
                    <Label>Tipo Combustible</Label>
                    <Select value={form.fuelType} onValueChange={v => setForm({ ...form, fuelType: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {FUEL_TYPES.map(f => <SelectItem key={f} value={f}>{f}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
              <div className="grid grid-cols-2 gap-4">
                {form.type === 'FUEL' && (
                  <div className="space-y-2">
                    <Label>Galones</Label>
                    <Input type="number" step="0.01" value={form.gallons} onChange={(e: any) => setForm({ ...form, gallons: e.target.value })} />
                  </div>
                )}
                <div className="space-y-2">
                  <Label>Monto (Q) *</Label>
                  <Input type="number" step="0.01" value={form.amount} onChange={(e: any) => setForm({ ...form, amount: e.target.value })} required />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Descripción</Label>
                <Input value={form.description} onChange={(e: any) => setForm({ ...form, description: e.target.value })} placeholder="Nota opcional" />
              </div>
              <Button type="submit" className="w-full">Registrar Transacción</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card><CardContent className="p-4 text-center"><p className="text-xs text-muted-foreground uppercase">Total Ventas</p><p className="text-xl font-bold font-mono mt-1">{formatCurrency(totals.amount)}</p></CardContent></Card>
        <Card><CardContent className="p-4 text-center"><p className="text-xs text-muted-foreground uppercase">Puntos Emitidos</p><p className="text-xl font-bold font-mono mt-1 text-amber-500">{formatNumber(totals.points)}</p></CardContent></Card>
        <Card><CardContent className="p-4 text-center"><p className="text-xs text-muted-foreground uppercase">Transacciones</p><p className="text-xl font-bold font-mono mt-1">{totals.count}</p></CardContent></Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <Select value={stationFilter} onValueChange={setStationFilter}>
          <SelectTrigger className="w-[200px]"><SelectValue placeholder="Todas las estaciones" /></SelectTrigger>
          <SelectContent>
            <SelectItem value=" ">Todas las estaciones</SelectItem>
            {stations.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={days} onValueChange={setDays}>
          <SelectTrigger className="w-[150px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="7">Últimos 7 días</SelectItem>
            <SelectItem value="30">Últimos 30 días</SelectItem>
            <SelectItem value="90">Últimos 90 días</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Cliente</TableHead>
                <TableHead>Estación</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead className="text-right">Monto</TableHead>
                <TableHead className="text-right">Puntos</TableHead>
                <TableHead>Fecha</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow><TableCell colSpan={6} className="text-center py-8">Cargando...</TableCell></TableRow>
              ) : transactions.length === 0 ? (
                <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No hay transacciones</TableCell></TableRow>
              ) : transactions.map(t => (
                <TableRow key={t.id}>
                  <TableCell className="font-medium">{t.customer.firstName} {t.customer.lastName}</TableCell>
                  <TableCell>{t.station.name}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className="text-xs">
                      {t.type === 'FUEL' ? `${t.fuelType}` : t.type === 'STORE' ? 'Tienda' : 'Bono'}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right font-mono">{formatCurrency(t.amount)}</TableCell>
                  <TableCell className="text-right">
                    <span className="flex items-center justify-end gap-1 font-mono text-green-600 font-semibold">
                      <Star className="w-3 h-3" /> +{formatNumber(t.pointsEarned)}
                    </span>
                  </TableCell>
                  <TableCell className="text-muted-foreground text-sm">{new Date(t.date).toLocaleDateString('es-GT')}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
