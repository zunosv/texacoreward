import { TransactionsContent } from './_components/transactions-content'
export const dynamic = 'force-dynamic'
export default function TransactionsPage() { return <TransactionsContent /> }
