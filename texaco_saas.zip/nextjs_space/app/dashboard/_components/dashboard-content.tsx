'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Users, Star, ArrowLeftRight, Gift, TrendingUp, Trophy, Megaphone, MapPin } from 'lucide-react'
import dynamic from 'next/dynamic'

const PointsChart = dynamic(() => import('./points-chart'), { ssr: false })
const TierChart = dynamic(() => import('./tier-chart'), { ssr: false })

const TIER_COLORS: Record<string, string> = {
  BRONCE: '#CD7F32',
  PLATA: '#C0C0C0',
  ORO: '#B8860B',
  PLATINO: '#7B7B7B',
}

function formatNumber(n: number) {
  return new Intl.NumberFormat('es-GT').format(n)
}

function formatCurrency(n: number) {
  return `Q ${new Intl.NumberFormat('es-GT', { minimumFractionDigits: 2 }).format(n)}`
}

export function DashboardContent() {
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/dashboard')
      .then(r => r.json())
      .then(setData)
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [])

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse"><CardContent className="p-6"><div className="h-16 bg-muted rounded" /></CardContent></Card>
          ))}
        </div>
      </div>
    )
  }

  if (!data) return <p className="text-muted-foreground">Error al cargar datos</p>

  const stats = [
    { label: 'Clientes Activos', value: formatNumber(data.activeCustomers), total: `${formatNumber(data.totalCustomers)} total`, icon: Users, color: 'text-blue-600' },
    { label: 'Puntos Emitidos Hoy', value: formatNumber(data.today.points), total: `${data.today.count} transacciones`, icon: Star, color: 'text-amber-500' },
    { label: 'Ventas del Mes', value: formatCurrency(data.month.amount), total: `${formatNumber(data.month.count)} operaciones`, icon: TrendingUp, color: 'text-green-600' },
    { label: 'Canjes Pendientes', value: formatNumber(data.pendingRedemptions), total: `${data.activePromotions} promos activas`, icon: Gift, color: 'text-primary' },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display text-2xl font-bold tracking-tight">Dashboard</h2>
        <p className="text-muted-foreground text-sm mt-1">Resumen del programa de fidelización TEXACO Rewards</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <Card key={i}>
            <CardContent className="p-5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{stat.label}</p>
                  <p className="text-2xl font-bold font-mono mt-1">{stat.value}</p>
                  <p className="text-xs text-muted-foreground mt-1">{stat.total}</p>
                </div>
                <div className={`p-2 rounded-lg bg-muted ${stat.color}`}>
                  <stat.icon className="w-5 h-5" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold">Puntos Emitidos - Últimos 7 días</CardTitle>
          </CardHeader>
          <CardContent>
            <PointsChart data={data.dailyPoints || []} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold">Distribución por Nivel</CardTitle>
          </CardHeader>
          <CardContent>
            <TierChart data={data.tierDistribution || []} />
          </CardContent>
        </Card>
      </div>

      {/* Bottom section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Customers */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Trophy className="w-4 h-4 text-amber-500" /> Top Clientes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {(data.topCustomers || []).map((c: any, i: number) => (
                <div key={c.id} className="flex items-center gap-3">
                  <span className="text-sm font-mono text-muted-foreground w-5">#{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{c.firstName} {c.lastName}</p>
                    <p className="text-xs text-muted-foreground">{formatNumber(c.lifetimePoints)} pts acumulados</p>
                  </div>
                  <Badge variant="outline" style={{ borderColor: TIER_COLORS[c.tier], color: TIER_COLORS[c.tier] }}>
                    {c.tier}
                  </Badge>
                  <span className="text-sm font-mono font-semibold">{formatNumber(c.totalPoints)}</span>
                </div>
              ))}
              {(!data.topCustomers || data.topCustomers.length === 0) && (
                <p className="text-sm text-muted-foreground text-center py-4">No hay clientes registrados aún</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Recent Transactions */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <ArrowLeftRight className="w-4 h-4 text-primary" /> Transacciones Recientes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {(data.recentTransactions || []).slice(0, 5).map((t: any) => (
                <div key={t.id} className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                    <Star className="w-4 h-4 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{t.customer.firstName} {t.customer.lastName}</p>
                    <p className="text-xs text-muted-foreground">{t.station.name} · {t.type}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-mono font-semibold text-green-600">+{formatNumber(t.pointsEarned)} pts</p>
                    <p className="text-xs text-muted-foreground">{formatCurrency(t.amount)}</p>
                  </div>
                </div>
              ))}
              {(!data.recentTransactions || data.recentTransactions.length === 0) && (
                <p className="text-sm text-muted-foreground text-center py-4">No hay transacciones aún</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Stats Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <Star className="w-5 h-5 mx-auto text-amber-500 mb-1" />
            <p className="text-lg font-bold font-mono">{formatNumber(data.totalPointsIssued)}</p>
            <p className="text-xs text-muted-foreground">Puntos Emitidos Total</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Gift className="w-5 h-5 mx-auto text-primary mb-1" />
            <p className="text-lg font-bold font-mono">{formatNumber(data.totalPointsRedeemed)}</p>
            <p className="text-xs text-muted-foreground">Puntos Canjeados</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Megaphone className="w-5 h-5 mx-auto text-blue-500 mb-1" />
            <p className="text-lg font-bold font-mono">{data.activePromotions}</p>
            <p className="text-xs text-muted-foreground">Promos Activas</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <MapPin className="w-5 h-5 mx-auto text-green-600 mb-1" />
            <p className="text-lg font-bold font-mono">{data.totalStations}</p>
            <p className="text-xs text-muted-foreground">Estaciones</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
