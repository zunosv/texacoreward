import { ConfigContent } from './_components/config-content'
export const dynamic = 'force-dynamic'
export default function ConfigPage() { return <ConfigContent /> }
