'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { toast } from 'sonner'
import { Settings, Star, Award, Save } from 'lucide-react'

const DEFAULT_POINTS = [
  { fuelType: 'REGULAR', pointsPerQuetzal: 1, description: 'Puntos por Q1 de Regular' },
  { fuelType: 'PREMIUM', pointsPerQuetzal: 1.5, description: 'Puntos por Q1 de Premium' },
  { fuelType: 'DIESEL', pointsPerQuetzal: 1, description: 'Puntos por Q1 de Diésel' },
  { fuelType: 'STORE', pointsPerQuetzal: 0.5, description: 'Puntos por Q1 en tienda' },
]

const DEFAULT_TIERS = [
  { name: 'BRONCE', minPoints: 0, multiplier: 1.0, color: '#CD7F32', benefits: 'Acumulación básica de puntos' },
  { name: 'PLATA', minPoints: 5000, multiplier: 1.25, color: '#C0C0C0', benefits: '25% más puntos en cada compra' },
  { name: 'ORO', minPoints: 15000, multiplier: 1.5, color: '#FFD700', benefits: '50% más puntos + recompensas exclusivas' },
  { name: 'PLATINO', minPoints: 50000, multiplier: 2.0, color: '#E5E4E2', benefits: 'Puntos dobles + beneficios VIP' },
]

export function ConfigContent() {
  const [pointsConfig, setPointsConfig] = useState(DEFAULT_POINTS)
  const [tierConfig, setTierConfig] = useState(DEFAULT_TIERS)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    fetch('/api/config')
      .then(r => r.json())
      .then(data => {
        if (data.pointsConfig && data.pointsConfig.length > 0) setPointsConfig(data.pointsConfig)
        if (data.tierConfig && data.tierConfig.length > 0) setTierConfig(data.tierConfig)
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  const handleSave = async () => {
    setSaving(true)
    try {
      const res = await fetch('/api/config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pointsConfig, tierConfig }),
      })
      if (!res.ok) { toast.error('Error al guardar'); return }
      toast.success('Configuración guardada exitosamente')
    } catch { toast.error('Error') } finally { setSaving(false) }
  }

  const updatePoints = (index: number, field: string, value: any) => {
    const updated = [...pointsConfig]
    updated[index] = { ...updated[index], [field]: value }
    setPointsConfig(updated)
  }

  const updateTier = (index: number, field: string, value: any) => {
    const updated = [...tierConfig]
    updated[index] = { ...updated[index], [field]: value }
    setTierConfig(updated)
  }

  if (loading) return <div className="space-y-4">{[...Array(2)].map((_, i) => <Card key={i} className="animate-pulse"><CardContent className="p-6"><div className="h-32 bg-muted rounded" /></CardContent></Card>)}</div>

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold tracking-tight flex items-center gap-2">
            <Settings className="w-6 h-6 text-primary" /> Configuración
          </h2>
          <p className="text-sm text-muted-foreground mt-1">Ajusta las reglas del programa de fidelización</p>
        </div>
        <Button onClick={handleSave} disabled={saving}>
          <Save className="w-4 h-4 mr-2" /> {saving ? 'Guardando...' : 'Guardar Cambios'}
        </Button>
      </div>

      {/* Points Config */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base font-semibold flex items-center gap-2">
            <Star className="w-4 h-4 text-amber-500" /> Tasa de Acumulación de Puntos
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {pointsConfig.map((pc, i) => (
              <div key={pc.fuelType} className="border rounded-lg p-4">
                <Label className="font-semibold text-sm">{pc.fuelType}</Label>
                <p className="text-xs text-muted-foreground mb-2">{pc.description}</p>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    step="0.1"
                    value={pc.pointsPerQuetzal}
                    onChange={(e: any) => updatePoints(i, 'pointsPerQuetzal', e.target.value)}
                    className="w-24"
                  />
                  <span className="text-sm text-muted-foreground">puntos por Q1</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Tier Config */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base font-semibold flex items-center gap-2">
            <Award className="w-4 h-4 text-primary" /> Niveles de Fidelización
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {tierConfig.map((tc, i) => (
              <div key={tc.name} className="border rounded-lg p-4">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-4 h-4 rounded-full" style={{ backgroundColor: tc.color }} />
                  <span className="font-semibold">{tc.name}</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <Label className="text-xs">Puntos mínimos</Label>
                    <Input type="number" value={tc.minPoints} onChange={(e: any) => updateTier(i, 'minPoints', e.target.value)} />
                  </div>
                  <div>
                    <Label className="text-xs">Multiplicador</Label>
                    <Input type="number" step="0.05" value={tc.multiplier} onChange={(e: any) => updateTier(i, 'multiplier', e.target.value)} />
                  </div>
                  <div>
                    <Label className="text-xs">Beneficios</Label>
                    <Input value={tc.benefits || ''} onChange={(e: any) => updateTier(i, 'benefits', e.target.value)} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
