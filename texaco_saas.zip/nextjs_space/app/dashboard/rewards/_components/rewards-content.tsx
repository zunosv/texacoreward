'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { toast } from 'sonner'
import { Gift, Plus, Star, Edit, Trash2, Package } from 'lucide-react'

const CATEGORIES = [
  { value: 'FUEL', label: 'Combustible' },
  { value: 'STORE', label: 'Tienda' },
  { value: 'EXPERIENCE', label: 'Experiencia' },
  { value: 'MERCHANDISE', label: 'Mercancía' },
]

function formatNumber(n: number) { return new Intl.NumberFormat('es-GT').format(n) }

export function RewardsContent() {
  const [rewards, setRewards] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editing, setEditing] = useState<any>(null)
  const [form, setForm] = useState({ name: '', description: '', pointsCost: '', category: 'FUEL', stock: '-1', validUntil: '' })

  const fetchRewards = () => {
    fetch('/api/rewards').then(r => r.json()).then(setRewards).catch(() => toast.error('Error')).finally(() => setLoading(false))
  }

  useEffect(() => { fetchRewards() }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const url = editing ? `/api/rewards/${editing.id}` : '/api/rewards'
      const method = editing ? 'PUT' : 'POST'
      const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) })
      const data = await res.json()
      if (!res.ok) { toast.error(data.error); return }
      toast.success(editing ? 'Recompensa actualizada' : 'Recompensa creada')
      setDialogOpen(false)
      setEditing(null)
      setForm({ name: '', description: '', pointsCost: '', category: 'FUEL', stock: '-1', validUntil: '' })
      fetchRewards()
    } catch { toast.error('Error') }
  }

  const handleEdit = (r: any) => {
    setEditing(r)
    setForm({ name: r.name, description: r.description || '', pointsCost: String(r.pointsCost), category: r.category, stock: String(r.stock), validUntil: r.validUntil ? r.validUntil.split('T')[0] : '' })
    setDialogOpen(true)
  }

  const handleToggle = async (r: any) => {
    await fetch(`/api/rewards/${r.id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ isActive: !r.isActive }) })
    fetchRewards()
  }

  const handleDelete = async (id: string) => {
    if (!confirm('¿Eliminar esta recompensa?')) return
    await fetch(`/api/rewards/${id}`, { method: 'DELETE' })
    toast.success('Recompensa eliminada')
    fetchRewards()
  }

  const catLabel = (cat: string) => CATEGORIES.find(c => c.value === cat)?.label || cat

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold tracking-tight flex items-center gap-2">
            <Gift className="w-6 h-6 text-primary" /> Recompensas
          </h2>
          <p className="text-sm text-muted-foreground mt-1">Catálogo de recompensas canjeables con puntos</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={(open) => { setDialogOpen(open); if (!open) { setEditing(null); setForm({ name: '', description: '', pointsCost: '', category: 'FUEL', stock: '-1', validUntil: '' }) } }}>
          <DialogTrigger asChild>
            <Button><Plus className="w-4 h-4 mr-2" /> Nueva Recompensa</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>{editing ? 'Editar Recompensa' : 'Nueva Recompensa'}</DialogTitle></DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2"><Label>Nombre *</Label><Input value={form.name} onChange={(e: any) => setForm({ ...form, name: e.target.value })} required placeholder="5 galones de Regular gratis" /></div>
              <div className="space-y-2"><Label>Descripción</Label><Input value={form.description} onChange={(e: any) => setForm({ ...form, description: e.target.value })} placeholder="Descripción de la recompensa" /></div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Costo en Puntos *</Label>
                  <Input type="number" value={form.pointsCost} onChange={(e: any) => setForm({ ...form, pointsCost: e.target.value })} required />
                </div>
                <div className="space-y-2">
                  <Label>Categoría *</Label>
                  <Select value={form.category} onValueChange={v => setForm({ ...form, category: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{CATEGORIES.map(c => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2"><Label>Stock (-1 = ilimitado)</Label><Input type="number" value={form.stock} onChange={(e: any) => setForm({ ...form, stock: e.target.value })} /></div>
                <div className="space-y-2"><Label>Válido hasta</Label><Input type="date" value={form.validUntil} onChange={(e: any) => setForm({ ...form, validUntil: e.target.value })} /></div>
              </div>
              <Button type="submit" className="w-full">{editing ? 'Actualizar' : 'Crear'}</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(3)].map((_, i) => <Card key={i} className="animate-pulse"><CardContent className="p-6"><div className="h-28 bg-muted rounded" /></CardContent></Card>)}
        </div>
      ) : rewards.length === 0 ? (
        <Card><CardContent className="p-12 text-center"><Gift className="w-12 h-12 mx-auto text-muted-foreground mb-3" /><p className="text-muted-foreground">No hay recompensas creadas</p></CardContent></Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {rewards.map(r => (
            <Card key={r.id} className={`hover:shadow-md transition-shadow ${!r.isActive ? 'opacity-60' : ''}`}>
              <CardContent className="p-5">
                <div className="flex items-start justify-between mb-2">
                  <Badge variant="outline" className="text-xs">{catLabel(r.category)}</Badge>
                  <Switch checked={r.isActive} onCheckedChange={() => handleToggle(r)} />
                </div>
                <h3 className="font-semibold text-base mb-1">{r.name}</h3>
                {r.description && <p className="text-sm text-muted-foreground mb-3">{r.description}</p>}
                <div className="flex items-center gap-2 mb-3">
                  <Star className="w-5 h-5 text-amber-500" />
                  <span className="font-mono font-bold text-xl">{formatNumber(r.pointsCost)}</span>
                  <span className="text-sm text-muted-foreground">puntos</span>
                </div>
                <div className="flex items-center gap-3 text-xs text-muted-foreground mb-3">
                  <span className="flex items-center gap-1"><Package className="w-3 h-3" /> {r.stock === -1 ? 'Ilimitado' : `${r.stock} disponibles`}</span>
                  <span>{r._count?.redemptions || 0} canjes</span>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => handleEdit(r)} className="flex-1"><Edit className="w-3 h-3 mr-1" /> Editar</Button>
                  <Button variant="outline" size="sm" onClick={() => handleDelete(r.id)} className="text-destructive hover:text-destructive"><Trash2 className="w-3 h-3" /></Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
