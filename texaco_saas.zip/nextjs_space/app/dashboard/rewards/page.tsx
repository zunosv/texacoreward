import { RewardsContent } from './_components/rewards-content'
export const dynamic = 'force-dynamic'
export default function RewardsPage() { return <RewardsContent /> }
