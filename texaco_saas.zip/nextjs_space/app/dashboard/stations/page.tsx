import { StationsContent } from './_components/stations-content'
export const dynamic = 'force-dynamic'
export default function StationsPage() { return <StationsContent /> }
