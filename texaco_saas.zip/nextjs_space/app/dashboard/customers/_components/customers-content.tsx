'use client'

import { useEffect, useState, useCallback } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { toast } from 'sonner'
import { Users, Plus, Search, Star, Phone, Mail, Edit, Trash2 } from 'lucide-react'

const TIER_COLORS: Record<string, string> = {
  BRONCE: '#CD7F32',
  PLATA: '#C0C0C0',
  ORO: '#B8860B',
  PLATINO: '#7B7B7B',
}

const TIERS = ['BRONCE', 'PLATA', 'ORO', 'PLATINO']

function formatNumber(n: number) {
  return new Intl.NumberFormat('es-GT').format(n)
}

export function CustomersContent() {
  const [customers, setCustomers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [tierFilter, setTierFilter] = useState('')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editing, setEditing] = useState<any>(null)
  const [form, setForm] = useState({ firstName: '', lastName: '', email: '', phone: '', dpi: '' })

  const fetchCustomers = useCallback(() => {
    const params = new URLSearchParams()
    if (search) params.set('search', search)
    if (tierFilter) params.set('tier', tierFilter)
    fetch(`/api/customers?${params}`)
      .then(r => r.json())
      .then(d => setCustomers(d.customers || []))
      .catch(() => toast.error('Error al cargar clientes'))
      .finally(() => setLoading(false))
  }, [search, tierFilter])

  useEffect(() => { fetchCustomers() }, [fetchCustomers])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const url = editing ? `/api/customers/${editing.id}` : '/api/customers'
      const method = editing ? 'PUT' : 'POST'
      const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) })
      const data = await res.json()
      if (!res.ok) { toast.error(data.error); return }
      toast.success(editing ? 'Cliente actualizado' : 'Cliente registrado')
      setDialogOpen(false)
      setEditing(null)
      setForm({ firstName: '', lastName: '', email: '', phone: '', dpi: '' })
      fetchCustomers()
    } catch { toast.error('Error de conexión') }
  }

  const handleEdit = (c: any) => {
    setEditing(c)
    setForm({ firstName: c.firstName, lastName: c.lastName, email: c.email || '', phone: c.phone, dpi: c.dpi || '' })
    setDialogOpen(true)
  }

  const handleDelete = async (id: string) => {
    if (!confirm('¿Eliminar este cliente?')) return
    try {
      await fetch(`/api/customers/${id}`, { method: 'DELETE' })
      toast.success('Cliente eliminado')
      fetchCustomers()
    } catch { toast.error('Error al eliminar') }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold tracking-tight flex items-center gap-2">
            <Users className="w-6 h-6 text-primary" /> Clientes
          </h2>
          <p className="text-sm text-muted-foreground mt-1">Gestiona los clientes del programa de fidelización</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={(open) => { setDialogOpen(open); if (!open) { setEditing(null); setForm({ firstName: '', lastName: '', email: '', phone: '', dpi: '' }) } }}>
          <DialogTrigger asChild>
            <Button><Plus className="w-4 h-4 mr-2" /> Nuevo Cliente</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editing ? 'Editar Cliente' : 'Registrar Nuevo Cliente'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Nombre *</Label>
                  <Input value={form.firstName} onChange={(e: any) => setForm({ ...form, firstName: e.target.value })} required />
                </div>
                <div className="space-y-2">
                  <Label>Apellido *</Label>
                  <Input value={form.lastName} onChange={(e: any) => setForm({ ...form, lastName: e.target.value })} required />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Teléfono *</Label>
                <Input value={form.phone} onChange={(e: any) => setForm({ ...form, phone: e.target.value })} required placeholder="5555-1234" />
              </div>
              <div className="space-y-2">
                <Label>Email</Label>
                <Input type="email" value={form.email} onChange={(e: any) => setForm({ ...form, email: e.target.value })} placeholder="cliente@email.com" />
              </div>
              <div className="space-y-2">
                <Label>DPI</Label>
                <Input value={form.dpi} onChange={(e: any) => setForm({ ...form, dpi: e.target.value })} placeholder="1234567890101" />
              </div>
              <Button type="submit" className="w-full">{editing ? 'Actualizar' : 'Registrar'}</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Buscar por nombre, teléfono o email..." value={search} onChange={(e: any) => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={tierFilter} onValueChange={setTierFilter}>
          <SelectTrigger className="w-[160px]"><SelectValue placeholder="Todos los niveles" /></SelectTrigger>
          <SelectContent>
            <SelectItem value=" ">Todos los niveles</SelectItem>
            {TIERS.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {/* Customers list */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => <Card key={i} className="animate-pulse"><CardContent className="p-6"><div className="h-24 bg-muted rounded" /></CardContent></Card>)}
        </div>
      ) : customers.length === 0 ? (
        <Card><CardContent className="p-12 text-center"><Users className="w-12 h-12 mx-auto text-muted-foreground mb-3" /><p className="text-muted-foreground">No hay clientes registrados</p></CardContent></Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {customers.map(c => (
            <Card key={c.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-semibold text-base">{c.firstName} {c.lastName}</h3>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                      <Phone className="w-3 h-3" /> {c.phone}
                    </div>
                    {c.email && <div className="flex items-center gap-1 text-xs text-muted-foreground"><Mail className="w-3 h-3" /> {c.email}</div>}
                  </div>
                  <Badge variant="outline" style={{ borderColor: TIER_COLORS[c.tier], color: TIER_COLORS[c.tier] }} className="font-semibold">
                    {c.tier}
                  </Badge>
                </div>
                <div className="flex items-center gap-4 mb-3">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-amber-500" />
                    <span className="font-mono font-bold text-lg">{formatNumber(c.totalPoints)}</span>
                    <span className="text-xs text-muted-foreground">pts</span>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {formatNumber(c.lifetimePoints)} acumulados
                  </div>
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground mb-3">
                  <span>{c._count?.transactions || 0} transacciones</span>
                  <span>·</span>
                  <span>{c._count?.redemptions || 0} canjes</span>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => handleEdit(c)} className="flex-1">
                    <Edit className="w-3 h-3 mr-1" /> Editar
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleDelete(c.id)} className="text-destructive hover:text-destructive">
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
