'use client'

import { useEffect, useState, useCallback } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { toast } from 'sonner'
import { Trophy, Plus, Star, Search, Check, X } from 'lucide-react'

function formatNumber(n: number) { return new Intl.NumberFormat('es-GT').format(n) }

const STATUS_MAP: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
  PENDING: { label: 'Pendiente', variant: 'outline' },
  COMPLETED: { label: 'Completado', variant: 'default' },
  CANCELLED: { label: 'Cancelado', variant: 'destructive' },
}

export function RedemptionsContent() {
  const [redemptions, setRedemptions] = useState<any[]>([])
  const [rewards, setRewards] = useState<any[]>([])
  const [customers, setCustomers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [statusFilter, setStatusFilter] = useState('')
  const [customerSearch, setCustomerSearch] = useState('')
  const [form, setForm] = useState({ customerId: '', rewardId: '' })

  const fetchRedemptions = useCallback(() => {
    const params = new URLSearchParams()
    if (statusFilter) params.set('status', statusFilter)
    fetch(`/api/redemptions?${params}`)
      .then(r => r.json())
      .then(d => setRedemptions(d.redemptions || []))
      .catch(() => toast.error('Error'))
      .finally(() => setLoading(false))
  }, [statusFilter])

  useEffect(() => { fetchRedemptions() }, [fetchRedemptions])
  useEffect(() => { fetch('/api/rewards').then(r => r.json()).then(d => setRewards(Array.isArray(d) ? d.filter((r: any) => r.isActive) : [])) }, [])

  useEffect(() => {
    if (customerSearch.length >= 2) {
      fetch(`/api/customers?search=${customerSearch}&limit=10`)
        .then(r => r.json())
        .then(d => setCustomers(d.customers || []))
    } else setCustomers([])
  }, [customerSearch])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const res = await fetch('/api/redemptions', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) })
      const data = await res.json()
      if (!res.ok) { toast.error(data.error); return }
      toast.success('Canje registrado exitosamente')
      setDialogOpen(false)
      setForm({ customerId: '', rewardId: '' })
      setCustomerSearch('')
      fetchRedemptions()
    } catch { toast.error('Error') }
  }

  const updateStatus = async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/redemptions/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) })
      if (!res.ok) { toast.error('Error al actualizar'); return }
      toast.success(`Canje ${status === 'COMPLETED' ? 'completado' : 'cancelado'}`)
      fetchRedemptions()
    } catch { toast.error('Error') }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold tracking-tight flex items-center gap-2">
            <Trophy className="w-6 h-6 text-primary" /> Canjes
          </h2>
          <p className="text-sm text-muted-foreground mt-1">Gestiona los canjes de recompensas</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="w-4 h-4 mr-2" /> Nuevo Canje</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Canjear Recompensa</DialogTitle></DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>Cliente *</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input placeholder="Buscar cliente..." value={customerSearch} onChange={(e: any) => { setCustomerSearch(e.target.value); setForm({ ...form, customerId: '' }) }} className="pl-9" />
                </div>
                {customers.length > 0 && !form.customerId && (
                  <div className="border rounded-lg max-h-32 overflow-y-auto">
                    {customers.map(c => (
                      <button key={c.id} type="button" onClick={() => { setForm({ ...form, customerId: c.id }); setCustomerSearch(`${c.firstName} ${c.lastName} (${formatNumber(c.totalPoints)} pts)`) }} className="w-full text-left px-3 py-2 text-sm hover:bg-muted">
                        {c.firstName} {c.lastName} <span className="text-muted-foreground">- {formatNumber(c.totalPoints)} pts</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <div className="space-y-2">
                <Label>Recompensa *</Label>
                <Select value={form.rewardId} onValueChange={v => setForm({ ...form, rewardId: v })}>
                  <SelectTrigger><SelectValue placeholder="Seleccionar recompensa" /></SelectTrigger>
                  <SelectContent>
                    {rewards.map(r => (
                      <SelectItem key={r.id} value={r.id}>
                        {r.name} - {formatNumber(r.pointsCost)} pts
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button type="submit" className="w-full">Canjear</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex gap-3">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[180px]"><SelectValue placeholder="Todos los estados" /></SelectTrigger>
          <SelectContent>
            <SelectItem value=" ">Todos</SelectItem>
            <SelectItem value="PENDING">Pendientes</SelectItem>
            <SelectItem value="COMPLETED">Completados</SelectItem>
            <SelectItem value="CANCELLED">Cancelados</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Cliente</TableHead>
                <TableHead>Recompensa</TableHead>
                <TableHead className="text-right">Puntos</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Fecha</TableHead>
                <TableHead>Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow><TableCell colSpan={6} className="text-center py-8">Cargando...</TableCell></TableRow>
              ) : redemptions.length === 0 ? (
                <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No hay canjes</TableCell></TableRow>
              ) : redemptions.map(r => (
                <TableRow key={r.id}>
                  <TableCell className="font-medium">{r.customer.firstName} {r.customer.lastName}</TableCell>
                  <TableCell>{r.reward.name}</TableCell>
                  <TableCell className="text-right font-mono">
                    <span className="flex items-center justify-end gap-1 text-red-500"><Star className="w-3 h-3" />-{formatNumber(r.pointsSpent)}</span>
                  </TableCell>
                  <TableCell>
                    <Badge variant={STATUS_MAP[r.status]?.variant || 'outline'}>{STATUS_MAP[r.status]?.label || r.status}</Badge>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">{new Date(r.redeemedAt).toLocaleDateString('es-GT')}</TableCell>
                  <TableCell>
                    {r.status === 'PENDING' && (
                      <div className="flex gap-1">
                        <Button variant="outline" size="sm" onClick={() => updateStatus(r.id, 'COMPLETED')} className="text-green-600 hover:text-green-700"><Check className="w-3 h-3" /></Button>
                        <Button variant="outline" size="sm" onClick={() => updateStatus(r.id, 'CANCELLED')} className="text-destructive hover:text-destructive"><X className="w-3 h-3" /></Button>
                      </div>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
