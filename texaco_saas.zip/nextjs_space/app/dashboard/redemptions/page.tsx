import { RedemptionsContent } from './_components/redemptions-content'
export const dynamic = 'force-dynamic'
export default function RedemptionsPage() { return <RedemptionsContent /> }
